#include "graphs/adjacency_matrix_graph.hpp"

std::unique_ptr<Graph> AdjacencyMatrixGraph::createGraph(std::istream& is)
{
    // TODO: implement
    FileReader reader(is);

    // Graph properties
    size_t graph_size = reader.get_graph_size();
    size_t edges_count = reader.get_edges_count();

    // Graph creation and setup
    auto graph = std::make_unique<AdjacencyMatrixGraph>();

    graph.get()->matrix = new std::vector<std::vector<Edge*>>(graph_size, std::vector<Edge*>(graph_size, nullptr));
    graph.get()->starting_vertex_index = reader.get_starting_vertex();
    graph.get()->size = graph_size;

    for(size_t index = 1; index < reader.get_lines().size() - 1; index++){
        std::vector<int> data = reader.parse(reader.get_lines()[index]);
        Vertex* v1 = new Vertex(data[0], false);
        Vertex* v2 = new Vertex(data[1], false);
        int weigth = data[2];

        graph.get()->insertVertex(v1);
        graph.get()->insertVertex(v2);
        graph.get()->insertEdge(v1, v2, weigth);
    }

    return graph;
}


void AdjacencyMatrixGraph::insertVertex(Vertex* v)
{
    for(auto obj : v_vector)
        if(v->index == obj->index)
            return;

    if(starting_vertex_index == v->index)
        starting_vertex = v;
    
    v_vector.push_back(v);
}

void AdjacencyMatrixGraph::insertEdge(Vertex* v1, Vertex* v2, int weight)
{
    Edge* edge = new Edge(v1, v2, weight);

    // check if needed to be reworked
    // include checks if Vertices exist
    //for(std::vector<Edge*> col : matrix)
    (*matrix)[v1->index][v2->index] = edge;
    e_vector.push_back(edge);
}

void AdjacencyMatrixGraph::removeVertex(Vertex* v)
{
    for(auto row : (*matrix))
        row[v->index] = nullptr;

    (*matrix)[v->index] = std::vector<Edge*>(size, nullptr);
    
}

void AdjacencyMatrixGraph::removeEdge(Edge* edge)
{
    (*matrix)[edge->v1->index][edge->v2->index] = nullptr;
}

std::vector<Edge*> AdjacencyMatrixGraph::incidentEdges(Vertex* v)
{
    std::vector<Edge*> buffer;

    for(auto row : (*matrix)[v->index])
        if(row != nullptr)
            buffer.push_back(row);

    return buffer;
}

std::vector<Edge*> AdjacencyMatrixGraph::edges()
{
    return e_vector;
}

std::vector<Vertex*> AdjacencyMatrixGraph::vertices()
{
    return v_vector;
}

std::vector<Vertex*> AdjacencyMatrixGraph::endVertices(Edge* edge)
{
    return {edge->v1, edge->v2};
}

Vertex* AdjacencyMatrixGraph::opposite(Vertex* v, Edge* egde)
{
    if(egde->v1 == v)
        return egde->v2;

    return egde->v1;
}

bool AdjacencyMatrixGraph::areAdjacent(Vertex* v1, Vertex* v2)
{
    return (*matrix)[v1->index][v2->index] != nullptr;
}

void AdjacencyMatrixGraph::replace(Vertex* v, std::string label)
{
    v->label = label;
}

void AdjacencyMatrixGraph::replace(Edge* edge, int weight)
{
    edge->weight = weight;
}

void AdjacencyMatrixGraph::visualise()
{
    for(size_t index = 0; index < size; index++){
        std::cout << index << "  [ ";
        for(auto row : (*matrix)[index])
            if(row != nullptr)
                std::cout << row->v2->index << " ";

        std::cout << "]" << std::endl;
    }
}

void AdjacencyMatrixGraph::visualiseFile(){

}

Vertex* AdjacencyMatrixGraph::get_starting_vertex()
{
    return starting_vertex;
}
